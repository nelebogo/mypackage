#mypackage
This library contains an example of a python packages

##building this python locally
`python setup.py sdist`

##installing this package from github
`pip install git+https://github.com/nelebogo/mypackage.git`

##updating this package from github
`pip install --upgrade git+https://github.com/nelebogo/mypackage.git`
